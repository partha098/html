<?php session_start(); ?>
<form action="lc.php" method="post">
	<p>Username</p>
	<p><input type="text" name="username"></p>
	<p>Password</p>
	<p><input type="password" name="password"></p>
	<p><input type="submit" name="lg" value="Login"></p>
	
</form>